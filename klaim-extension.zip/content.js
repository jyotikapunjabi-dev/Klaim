(function () {
  'use strict';
  if (window.__klaim_injected) return;
  window.__klaim_injected = true;

  const hostname = window.location.hostname;

  // Site-specific recommendations driven by Samvit's real portfolio.
  // Each entry: when the user lands on this site, what should we surface?
  // Logic: direct match if portfolio has a voucher for this site; otherwise
  // cross-retailer alternatives from the same category.
  const SITES = {
    'nykaa.com': {
      name: 'Nykaa',
      heading: "You don't have a Nykaa voucher right now.",
      subhead: "Your last Nykaa cashback expired last week. Your portfolio has 6 better plays for the same beauty range.",
      vouchers: [
        { brand: 'The Derma Co', label: '100% Cashback + 5% off prepaid', sub: 'Dermatology-led D2C — Honasa group', tone: '#0891B2', cta: 'Open Derma Co', url: 'https://thedermaco.com', urgency: '~45d', isNew: true },
        { brand: 'Tira', label: '30% off above ₹1,999', sub: 'Premium beauty selection (Reliance) — same brand range as Nykaa', tone: '#991B1B', cta: 'Open Tira', url: 'https://www.tirabeauty.com', urgency: '~21d' },
        { brand: 'Foxtale', label: 'Flat ₹400 off + ₹448 freebies', sub: 'Direct from Foxtale — D2C skincare', tone: '#9D174D', cta: 'Open Foxtale', url: 'https://foxtale.in', urgency: '~21d' },
        { brand: 'Minimalist', label: 'Free Sunscreen above ₹899', sub: 'Now Be Minimalist — direct site', tone: '#171717', cta: 'Open Minimalist', url: 'https://beminimalist.co', urgency: '~21d' },
      ],
    },
    'myntra.com': {
      name: 'Myntra',
      heading: 'No direct Myntra voucher.',
      subhead: 'But you have fashion alternatives — and a Puma deal burning out today.',
      vouchers: [
        { brand: 'Puma', label: 'Extra 33% off', sub: 'Sportswear: shoes, apparel, accessories', tone: '#171717', cta: 'Open Puma', url: 'https://in.puma.com', urgency: '1d', urgent: true, code: 'F4CBLNCGE6' },
        { brand: 'Nykaa Fashion', label: '₹5–100 cashback', sub: 'Mid-premium fashion (separate from Nykaa Beauty)', tone: '#BE185D', cta: 'Open Nykaa Fashion', url: 'https://nykaafashion.com', urgency: '6d' },
        { brand: 'GIVA', label: '20% off Fine Silver Jewellery', sub: 'Silver jewellery — direct site', tone: '#7F1D1D', cta: 'Open GIVA', url: 'https://www.giva.co', urgency: '~30d' },
        { brand: 'Meesho', label: '₹5–100 cashback', sub: 'Budget alternative for casual fashion', tone: '#DB2777', cta: 'Open Meesho', url: 'https://www.meesho.com', urgency: '6d' },
      ],
    },
    'amazon.in': {
      name: 'Amazon',
      heading: 'No Amazon voucher in your portfolio.',
      subhead: 'Most of what you\'d buy on Amazon is cheaper direct from the brand. Here\'s where vouchers actually apply.',
      vouchers: [
        { brand: 'Toothsi', label: 'Flat ₹20,000 off aligners', sub: 'Direct from MakeO (Tata) — only worth it if you\'re getting aligners', tone: '#DC2626', cta: 'Open Toothsi', url: 'https://makeo.app', urgency: '~30d', code: 'TOOTHSI20KOFF' },
        { brand: 'Lenskart', label: 'Free Gold Max (₹800 value)', sub: 'Eyewear — direct from Lenskart', tone: '#1D4ED8', cta: 'Open Lenskart', url: 'https://www.lenskart.com', urgency: '~30d' },
        { brand: 'D2C alternatives', label: 'Foxtale, Hyphen, Mamaearth, Derma Co', sub: 'Buying skincare on Amazon? Open the brand site to use your voucher.', tone: '#0F2547', cta: null, url: null },
      ],
    },
    'bigbasket.com': {
      name: 'BigBasket',
      heading: 'You have a BigBasket voucher.',
      subhead: 'Direct match — but read the caveat first.',
      vouchers: [
        { brand: 'BigBasket', label: '₹100 cashback on ₹149+', sub: 'Available via GPay Rewards', tone: '#65A30D', cta: 'Continue here', url: null, urgency: '~30d', caveat: 'New users only — check your account before assuming' },
        { brand: 'Zepto', label: '₹5–100 cashback', sub: 'If the BigBasket voucher doesn\'t apply: Zepto for same-day delivery', tone: '#7C3AED', cta: 'Open Zepto', url: 'https://www.zeptonow.com', urgency: '6d' },
      ],
    },
    'makemytrip.com': {
      name: 'MakeMyTrip',
      heading: 'No MMT voucher in your portfolio.',
      subhead: 'Cleartrip is often 5-8% cheaper for hotels — and you have 25% off there.',
      vouchers: [
        { brand: 'Cleartrip', label: '25% off Hotel Booking', sub: 'Same hotel inventory, often cheaper base price', tone: '#EA580C', cta: 'Open Cleartrip', url: 'https://www.cleartrip.com', urgency: '~30d' },
        { brand: 'Go', label: '15% off first domestic flight', sub: 'Max ₹1,500 discount — for first booking only', tone: '#F97316', cta: 'Compare flights', url: 'https://www.cleartrip.com/flights', urgency: '~30d' },
      ],
    },
    'bookmyshow.com': {
      name: 'BookMyShow',
      heading: 'No BookMyShow voucher.',
      subhead: 'But District (Zomato-owned) covers movies, dining, and live events — and you have cashback there.',
      vouchers: [
        { brand: 'District', label: '₹5–100 cashback', sub: 'Zomato\'s entertainment app — movies, dining, live events', tone: '#DC2626', cta: 'Open District', url: 'https://www.district.in', urgency: '6d' },
      ],
    },
    'tirabeauty.com': {
      name: 'Tira',
      heading: 'You have a Tira voucher — applies here.',
      subhead: '30% off above ₹1,999 will auto-apply at checkout. Klaim got you here from Nykaa. Job done.',
      vouchers: [
        { brand: 'Tira', label: '30% off above ₹1,999', sub: 'Auto-applied at checkout — premium beauty', tone: '#991B1B', cta: 'Continue shopping', url: null, urgency: '~21d' },
      ],
    },

    // Shopping aggregators — cross-retailer pivots
    'ajio.com': {
      name: 'Ajio',
      heading: 'No direct Ajio voucher.',
      subhead: 'But Nykaa Fashion has cashback live, and GIVA covers jewellery you might be browsing here.',
      vouchers: [
        { brand: 'Nykaa Fashion', label: '₹5–100 cashback', sub: 'Mid-premium fashion — overlapping inventory', tone: '#BE185D', cta: 'Open Nykaa Fashion', url: 'https://nykaafashion.com', urgency: '6d' },
        { brand: 'GIVA', label: '20% off Fine Silver Jewellery', sub: 'Direct from GIVA — silver & lab-grown diamonds', tone: '#7F1D1D', cta: 'Open GIVA', url: 'https://www.giva.co', urgency: '~30d' },
        { brand: 'Meesho', label: '₹5–100 cashback', sub: 'Budget alternative — same fast-fashion range', tone: '#DB2777', cta: 'Open Meesho', url: 'https://www.meesho.com', urgency: '6d' },
      ],
    },
    'croma.com': {
      name: 'Croma',
      heading: 'No Croma voucher in your portfolio yet.',
      subhead: "Electronics is a gap in your portfolio. The closest play is the Lenskart Gold Max if you're glasses-shopping — otherwise just buy direct here.",
      vouchers: [
        { brand: 'Lenskart', label: 'Free Gold Max (₹800 value)', sub: 'Eyewear — shop glasses/contacts directly', tone: '#1D4ED8', cta: 'Open Lenskart', url: 'https://www.lenskart.com', urgency: '~30d' },
      ],
    },
    'reliancedigital.in': {
      name: 'Reliance Digital',
      heading: 'No Reliance Digital voucher.',
      subhead: 'Same gap as Croma — electronics is uncovered. Buy direct here, but use Tira if you\'re also picking up beauty (Reliance group, often bundled).',
      vouchers: [
        { brand: 'Tira', label: '30% off above ₹1,999', sub: 'Reliance beauty arm — useful if mixing baskets', tone: '#991B1B', cta: 'Open Tira', url: 'https://www.tirabeauty.com', urgency: '~21d' },
      ],
    },
    'cleartrip.com': {
      name: 'Cleartrip',
      heading: 'You have a Cleartrip voucher — applies here.',
      subhead: '25% off hotel booking. Already the cheaper option vs MakeMyTrip for most hotels.',
      vouchers: [
        { brand: 'Cleartrip', label: '25% off Hotel Booking', sub: 'Auto-applied at checkout', tone: '#EA580C', cta: 'Continue booking', url: null, urgency: '~30d' },
        { brand: 'Go', label: '15% off first domestic flight (max ₹1,500)', sub: 'For flights — first booking only', tone: '#F97316', cta: 'Switch to flights', url: 'https://www.cleartrip.com/flights', urgency: '~30d' },
      ],
    },
    'zeptonow.com': {
      name: 'Zepto',
      heading: 'You have a Zepto voucher — applies here.',
      subhead: '₹5–100 cashback via GPay. Expires in 6 days. Perfect for top-up groceries.',
      vouchers: [
        { brand: 'Zepto', label: '₹5–100 cashback', sub: 'Use this checkout with GPay to claim', tone: '#7C3AED', cta: 'Continue shopping', url: null, urgency: '6d' },
        { brand: 'BigBasket', label: '₹100 cashback ₹149+', sub: 'For larger weekly shop — but new users only', tone: '#65A30D', cta: 'Compare on BigBasket', url: 'https://www.bigbasket.com', urgency: '~30d', caveat: 'New users only' },
      ],
    },
    'blinkit.com': {
      name: 'Blinkit',
      heading: 'Your Blinkit voucher just expired (last week).',
      subhead: 'Switch to Zepto where you still have ₹5–100 cashback live, expiring in 6 days.',
      vouchers: [
        { brand: 'Zepto', label: '₹5–100 cashback', sub: 'Same 10-min delivery, voucher still live', tone: '#7C3AED', cta: 'Open Zepto', url: 'https://www.zeptonow.com', urgency: '6d' },
      ],
    },
    'tatacliq.com': {
      name: 'Tata CLiQ',
      heading: 'No Tata CLiQ voucher.',
      subhead: 'But Tira is the Reliance beauty rival, Nykaa Fashion covers the apparel range, and Lenskart for eyewear.',
      vouchers: [
        { brand: 'Tira', label: '30% off above ₹1,999', sub: 'Beauty range — better margin than Tata CLiQ', tone: '#991B1B', cta: 'Open Tira', url: 'https://www.tirabeauty.com', urgency: '~21d' },
        { brand: 'Nykaa Fashion', label: '₹5–100 cashback', sub: 'Overlapping mid-premium fashion', tone: '#BE185D', cta: 'Open Nykaa Fashion', url: 'https://nykaafashion.com', urgency: '6d' },
      ],
    },

    // D2C brand confirmation panels — voucher applies, just confirm + show code
    'foxtale.in': {
      name: 'Foxtale',
      heading: 'Your Foxtale voucher applies here.',
      subhead: 'Flat ₹400 off + 2 freebies worth ₹448. Klaim brought you to the brand site for max value.',
      vouchers: [
        { brand: 'Foxtale', label: 'Flat ₹400 off + ₹448 freebies', sub: 'D2C skincare — Vit C, brightening, sunscreens', tone: '#9D174D', cta: 'Continue shopping', url: null, urgency: '~21d' },
      ],
    },
    'beminimalist.co': {
      name: 'Be Minimalist',
      heading: 'Your Minimalist voucher applies here.',
      subhead: 'Free Sunscreen on orders above ₹899. Code applies at checkout.',
      vouchers: [
        { brand: 'Minimalist', label: 'Free Sunscreen above ₹899', sub: 'Science-backed skincare — formerly Minimalist', tone: '#171717', cta: 'Continue shopping', url: null, urgency: '~21d' },
      ],
    },
    'hyphenbeauty.com': {
      name: 'Hyphen',
      heading: 'You have two Hyphen vouchers active.',
      subhead: 'Pick the better fit for your basket — both apply on this site.',
      vouchers: [
        { brand: 'Hyphen', label: 'Flat ₹200 off above ₹499 + 5% prepaid', sub: 'Best for smaller orders', tone: '#CA8A04', cta: 'Continue', url: null, urgency: '~21d' },
        { brand: 'Hyphen', label: 'Buy 3 @ ₹999 — serums, lip balms', sub: 'Best for stocking up', tone: '#CA8A04', cta: 'Continue', url: null, urgency: '~21d' },
      ],
    },
    'mamaearth.in': {
      name: 'Mamaearth',
      heading: 'No Mamaearth voucher in your portfolio.',
      subhead: 'But you have a NEW The Derma Co voucher (same Honasa group, similar range, much better deal).',
      vouchers: [
        { brand: 'The Derma Co', label: '100% Cashback + 5% off prepaid', sub: 'Honasa group — dermatology-led, better deal', tone: '#0891B2', cta: 'Open Derma Co', url: 'https://thedermaco.com', urgency: '~45d', isNew: true },
      ],
    },
    'lenskart.com': {
      name: 'Lenskart',
      heading: 'Your Lenskart voucher applies here.',
      subhead: 'Free Gold Max membership for 1 year (₹800 value). Auto-applies at checkout.',
      vouchers: [
        { brand: 'Lenskart', label: 'Free Gold Max (1 year, ₹800)', sub: 'Membership: 1 free pair + free home eye-test', tone: '#1D4ED8', cta: 'Continue', url: null, urgency: '~30d' },
      ],
    },
    'makeo.app': {
      name: 'Toothsi (MakeO)',
      heading: 'Your Toothsi voucher applies here.',
      subhead: 'Flat ₹20,000 off aligners. Use code TOOTHSI20KOFF — only worth using if you\'re actually getting aligners.',
      vouchers: [
        { brand: 'Toothsi', label: 'Flat ₹20,000 off aligners', sub: 'Dental aligners — Tata MakeO', tone: '#DC2626', cta: 'Continue', url: null, urgency: '~30d', code: 'TOOTHSI20KOFF' },
      ],
    },
  };

  // Find matching site
  let siteKey = null;
  for (const key of Object.keys(SITES)) {
    if (hostname.includes(key)) {
      siteKey = key;
      break;
    }
  }
  if (!siteKey) return;
  const config = SITES[siteKey];

  function init() {
    // Load Instrument Serif for the panel headings (with Georgia fallback if blocked)
    if (!document.querySelector('link[data-klaim-font]')) {
      const fontLink = document.createElement('link');
      fontLink.rel = 'stylesheet';
      fontLink.href = 'https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500;1,9..144,600&family=Inter:wght@400;500;600;700&display=swap';
      fontLink.setAttribute('data-klaim-font', 'true');
      document.head.appendChild(fontLink);
    }

    // Inject styles
    const style = document.createElement('style');
    style.id = 'klaim-styles';
    style.textContent = `
      #klaim-panel {
        position: fixed;
        top: 80px;
        right: 20px;
        width: 380px;
        max-width: calc(100vw - 40px);
        max-height: calc(100vh - 100px);
        background: #FAFAFA;
        border: 1px solid #E0E0E0;
        border-radius: 16px;
        box-shadow: 0 16px 56px rgba(0,0,0,0.20), 0 2px 8px rgba(0,0,0,0.06);
        z-index: 2147483647;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: #1A1815;
        animation: klaimSlideIn 0.55s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        overflow: hidden;
        display: flex;
        flex-direction: column;
      }
      @keyframes klaimSlideIn {
        from { transform: translateX(120%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      @keyframes klaimSlideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(120%); opacity: 0; }
      }
      #klaim-panel.klaim-closing { animation: klaimSlideOut 0.35s cubic-bezier(0.4, 0, 1, 1) forwards; }

      .klaim-header {
        background: #0F2547;
        color: #FAFAFA;
        padding: 14px 18px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-shrink: 0;
      }
      .klaim-brand { display: flex; align-items: center; gap: 8px; }
      .klaim-logo {
        width: 22px; height: 22px;
        background: #3B5C8A; color: #FAFAFA;
        border-radius: 5px;
        display: flex; align-items: center; justify-content: center;
        font-weight: 700; font-size: 13px;
      }
      .klaim-name { font-family: 'Fraunces', Georgia, serif; font-weight: 500; font-size: 19px; letter-spacing: -0.01em; }
      .klaim-tag {
        background: rgba(255, 255, 255, 0.14);
        color: #FAFAFA;
        font-size: 9px; font-weight: 600;
        text-transform: uppercase; letter-spacing: 0.1em;
        padding: 3px 7px; border-radius: 999px; margin-left: 4px;
      }
      .klaim-close {
        background: rgba(255,255,255,0.08);
        border: 0; color: #FAFAFA;
        width: 26px; height: 26px;
        border-radius: 50%; cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        font-size: 16px; line-height: 1;
        transition: background 0.15s;
        padding: 0;
      }
      .klaim-close:hover { background: rgba(255,255,255,0.18); }

      .klaim-body { padding: 18px; overflow-y: auto; flex: 1; }
      .klaim-heading {
        font-family: 'Fraunces', Georgia, serif;
        font-size: 22px; line-height: 1.2;
        margin: 0 0 6px 0; color: #1A1815;
      }
      .klaim-sub {
        font-size: 13px; color: #6B6862;
        margin: 0 0 14px 0; line-height: 1.5;
      }

      .klaim-voucher {
        background: white;
        border: 1px solid #E0E0E0;
        border-radius: 10px;
        padding: 12px;
        margin-bottom: 8px;
      }
      .klaim-voucher.klaim-urgent {
        border-color: #FCA5A5;
        background: linear-gradient(0deg, rgba(254, 226, 226, 0.5), rgba(254, 226, 226, 0.5)), white;
      }
      .klaim-v-row { display: flex; align-items: flex-start; gap: 10px; }
      .klaim-v-icon {
        width: 32px; height: 32px;
        border-radius: 8px;
        display: flex; align-items: center; justify-content: center;
        color: white; font-weight: 600; font-size: 11px;
        flex-shrink: 0;
      }
      .klaim-v-info { flex: 1; min-width: 0; }
      .klaim-v-brand {
        font-size: 13px; font-weight: 600; color: #1A1815;
        display: flex; align-items: center; gap: 6px;
      }
      .klaim-v-new {
        background: #0F2547; color: #FAFAFA;
        font-size: 9px; font-weight: 600;
        padding: 2px 5px; border-radius: 3px;
        letter-spacing: 0.04em;
      }
      .klaim-v-label {
        font-family: 'Fraunces', Georgia, serif;
        font-size: 16px; line-height: 1.25;
        margin-top: 2px; color: #1A1815;
      }
      .klaim-v-sub {
        font-size: 11.5px; color: #6B6862;
        margin-top: 4px; line-height: 1.4;
      }
      .klaim-v-urgency {
        font-size: 10px; font-weight: 600;
        padding: 3px 8px; border-radius: 999px;
        white-space: nowrap; flex-shrink: 0;
      }
      .klaim-v-urgency.urgent { background: #FEE2E2; color: #991B1B; }
      .klaim-v-urgency.warm { background: #FEF3C7; color: #92400E; }
      .klaim-v-urgency.normal { background: #EFEFEF; color: #6B6862; }

      .klaim-v-actions {
        display: flex; align-items: center; gap: 8px;
        margin-top: 10px; padding-top: 8px;
        border-top: 1px solid #E0E0E0;
      }
      .klaim-v-code {
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        font-size: 11px;
        background: #EFEFEF;
        padding: 3px 7px; border-radius: 4px;
        color: #1A1815;
      }
      .klaim-v-cta {
        background: #1A1815; color: #FAFAFA;
        border: 0; padding: 7px 12px;
        font-size: 11.5px; font-weight: 500;
        border-radius: 6px; cursor: pointer;
        text-decoration: none;
        margin-left: auto;
        display: inline-flex; align-items: center; gap: 4px;
        transition: background 0.15s;
      }
      .klaim-v-cta:hover { background: #0F2547; }
      .klaim-v-caveat {
        font-size: 10.5px; color: #92400E;
        margin-top: 8px; padding-top: 8px;
        border-top: 1px solid #FEF3C7;
        display: flex; align-items: flex-start; gap: 5px;
        line-height: 1.4;
      }

      .klaim-footer {
        background: #FAFAFA;
        padding: 11px 18px;
        font-size: 11.5px; color: #6B6862;
        text-align: center;
        border-top: 1px solid #E0E0E0;
        flex-shrink: 0;
      }
      .klaim-footer a {
        color: #0F2547; text-decoration: none; font-weight: 500;
      }
      .klaim-footer a:hover { text-decoration: underline; }
    `;
    document.head.appendChild(style);

    // Decide urgency class
    const urgencyClass = (urgencyStr, urgent) => {
      if (urgent) return 'urgent';
      if (!urgencyStr) return 'normal';
      const m = urgencyStr.match(/(\d+)d/);
      if (m) {
        const days = parseInt(m[1], 10);
        if (days <= 3) return 'urgent';
        if (days <= 7) return 'warm';
      }
      return 'normal';
    };

    // Build voucher cards
    const escapeHtml = (s) => String(s).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));

    const voucherHtml = config.vouchers.map((v) => {
      const initials = v.brand.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
      const uClass = urgencyClass(v.urgency, v.urgent);
      const showActions = v.cta || v.code;
      return `
        <div class="klaim-voucher ${v.urgent ? 'klaim-urgent' : ''}">
          <div class="klaim-v-row">
            <div class="klaim-v-icon" style="background: ${v.tone}">${escapeHtml(initials)}</div>
            <div class="klaim-v-info">
              <div class="klaim-v-brand">
                ${escapeHtml(v.brand)}
                ${v.isNew ? '<span class="klaim-v-new">NEW</span>' : ''}
              </div>
              <div class="klaim-v-label">${escapeHtml(v.label)}</div>
              <div class="klaim-v-sub">${escapeHtml(v.sub)}</div>
            </div>
            ${v.urgency ? `<div class="klaim-v-urgency ${uClass}">${escapeHtml(v.urgency)}</div>` : ''}
          </div>
          ${v.caveat ? `<div class="klaim-v-caveat">⚠ ${escapeHtml(v.caveat)}</div>` : ''}
          ${showActions ? `
            <div class="klaim-v-actions">
              ${v.code ? `<span class="klaim-v-code">${escapeHtml(v.code)}</span>` : ''}
              ${v.cta && v.url ? `<a class="klaim-v-cta" href="${escapeHtml(v.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(v.cta)} →</a>` : ''}
              ${v.cta && !v.url ? `<span class="klaim-v-cta" style="background: #6B6862; cursor: default">${escapeHtml(v.cta)}</span>` : ''}
            </div>
          ` : ''}
        </div>
      `;
    }).join('');

    const panel = document.createElement('div');
    panel.id = 'klaim-panel';
    panel.innerHTML = `
      <div class="klaim-header">
        <div class="klaim-brand">
          <div class="klaim-logo">K</div>
          <span class="klaim-name">Klaim</span>
          <span class="klaim-tag">on ${escapeHtml(config.name)}</span>
        </div>
        <button class="klaim-close" aria-label="Close">×</button>
      </div>
      <div class="klaim-body">
        <p class="klaim-heading">${escapeHtml(config.heading)}</p>
        <p class="klaim-sub">${escapeHtml(config.subhead)}</p>
        ${voucherHtml}
      </div>
      <div class="klaim-footer">
        <a href="#" id="klaim-open-dashboard">Open full Klaim dashboard →</a>
      </div>
    `;

    document.body.appendChild(panel);

    panel.querySelector('.klaim-close').addEventListener('click', () => {
      panel.classList.add('klaim-closing');
      setTimeout(() => panel.remove(), 350);
    });

    panel.querySelector('#klaim-open-dashboard').addEventListener('click', (e) => {
      e.preventDefault();
      // Klaim dashboard — Vercel production URL
      const dashboardUrl = window.KLAIM_DASHBOARD_URL || 'https://klaim-delta.vercel.app/';
      window.open(dashboardUrl, '_blank', 'noopener');
    });
  }

  if (document.body) {
    init();
  } else {
    document.addEventListener('DOMContentLoaded', init);
  }
})();
