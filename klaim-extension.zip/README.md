# Klaim — Chrome Extension (v0.1)

A demo Chrome extension that detects when you land on a major Indian shopping site and slides in a panel showing relevant vouchers from your portfolio — including cross-retailer recommendations when no direct match exists.

## Sites covered (v0.1)

- Nykaa
- Myntra
- Amazon.in
- BigBasket
- MakeMyTrip
- BookMyShow

## Install in 2 minutes (no coding needed)

1. Download / unzip this `klaim-extension` folder somewhere you'll remember (e.g. Desktop).
2. Open Chrome and go to: `chrome://extensions/`
3. Toggle **Developer mode** ON (top-right corner of the extensions page).
4. Click **Load unpacked**.
5. Select the `klaim-extension` folder you saved in step 1.
6. The Klaim extension is now installed. Open any of the 6 sites above and watch the panel slide in from the right.

If the panel doesn't appear: refresh the page (Cmd/Ctrl + R). The extension only injects on page load.

## What you'll see

| Site | Demo moment |
|---|---|
| Nykaa | "You don't have a Nykaa voucher — try Tira (30% off) or Derma Co (100% cashback NEW) instead" |
| Myntra | Puma 33% off badge **expires today**, plus Nykaa Fashion + GIVA + Meesho alternatives |
| Amazon | "No Amazon voucher. Most stuff is cheaper direct" → routes to Toothsi, Lenskart, D2C brands |
| BigBasket | Direct ₹100 cashback, but flags "new users only" caveat clearly |
| MakeMyTrip | Cleartrip 25% off pivot ("usually cheaper for hotels anyway") |
| BookMyShow | District ₹50 cashback (Zomato's BMS competitor) |

## Tips for recording the demo

- Visit Nykaa first — it's the strongest pitch moment (cross-retailer pivot is exactly the strategic insight you flagged in your application narrative).
- Then Myntra to show the urgency badge on the 1-day Puma voucher.
- Finally MakeMyTrip to show "we'll route you to the cheaper option" thinking.

## Architecture notes (for your "how I built it" section)

- **Manifest v3** (current Chrome standard, future-proof).
- **Content script** injected at `document_idle` so it doesn't block page load.
- **Hardcoded portfolio** for v1 demo — production version syncs with the Klaim dashboard via OAuth token + REST API.
- **Auto-slide animation** (550ms cubic-bezier) — same easing curve as the dashboard for visual coherence.
- **Cross-retailer logic** is the key insight: when no direct voucher exists for the current site, surface portfolio vouchers from the same category (e.g. Nykaa → Tira). This is what makes Klaim the *first stop before any purchase* rather than a passive voucher list.

## Troubleshooting

- **Panel doesn't appear**: check `chrome://extensions/`, ensure Klaim is toggled ON. Refresh the site. Disable any ad blockers temporarily — they sometimes block injected DOM.
- **Looks unstyled / wrong fonts**: some sites have strict CSP that blocks Google Fonts. The panel falls back to system serif (Georgia) — still readable, just not Instrument Serif.
- **Want to remove**: go to `chrome://extensions/` → Remove.
